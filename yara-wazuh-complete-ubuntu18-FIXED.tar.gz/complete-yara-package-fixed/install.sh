#!/bin/bash

# Complete YARA + Wazuh Installation for Ubuntu 18.04
# Self-contained package - no internet required!

set -e

# Colors
GREEN="\033[0;32m"
BLUE="\033[0;34m"
RED="\033[0;31m"
NC="\033[0m"

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

echo "=================================================="
echo "YARA + Wazuh Complete Installation (Ubuntu 18.04)"
echo "Self-contained - No internet required!"
echo "=================================================="

# Check if we are in the right directory
if [ ! -d "bin" ] || [ ! -d "openssl-libs" ] || [ ! -d "wazuh-yara" ]; then
    log_error "Missing required directories. Please run this script from the extracted package directory."
    log_error "Expected: bin/, openssl-libs/, wazuh-yara/"
    exit 1
fi

log_info "Installing OpenSSL 3.0 libraries..."
sudo mkdir -p /usr/local/openssl-3/lib64
sudo cp -r openssl-libs/* /usr/local/openssl-3/lib64/
echo "/usr/local/openssl-3/lib64" | sudo tee /etc/ld.so.conf.d/openssl-3.conf > /dev/null
sudo ldconfig
log_success "OpenSSL libraries installed"

log_info "Installing YARA binaries..."
sudo cp bin/yara /usr/local/bin/
sudo cp bin/yarac /usr/local/bin/
sudo chmod +x /usr/local/bin/yara /usr/local/bin/yarac
log_success "YARA binaries installed"

log_info "Testing YARA installation..."
if yara --version | grep -q "4.5.4"; then
    log_success "YARA 4.5.4 working correctly"
else
    log_error "YARA installation failed"
    exit 1
fi

log_info "Installing Wazuh integration (using local files)..."
if [ -d "/var/ossec" ]; then
    # Install YARA rules
    sudo mkdir -p /var/ossec/ruleset/yara/rules
    sudo cp wazuh-yara/rules/yara_rules.yar /var/ossec/ruleset/yara/rules/
    
    # Install active response script
    sudo mkdir -p /var/ossec/active-response/bin
    sudo cp wazuh-yara/scripts/yara.sh /var/ossec/active-response/bin/
    
    # Set proper permissions
    sudo chown -R root:wazuh /var/ossec/ruleset/yara/
    sudo chown root:wazuh /var/ossec/active-response/bin/yara.sh
    sudo chmod 750 /var/ossec/active-response/bin/yara.sh
    
    log_success "Wazuh integration completed using local files"
else
    log_info "Wazuh agent not detected - YARA installed standalone"
fi

echo
echo "=================================================="
log_success "Installation completed successfully!"
echo "=================================================="
echo "YARA version: $(yara --version)"
echo "Installation time: ~2 minutes"
echo "No internet connection was required!"
echo
echo "Files installed:"
echo "- YARA: /usr/local/bin/yara"
if [ -d "/var/ossec" ]; then
    echo "- Rules: /var/ossec/ruleset/yara/rules/yara_rules.yar ($(du -h /var/ossec/ruleset/yara/rules/yara_rules.yar | cut -f1))"
    echo "- Script: /var/ossec/active-response/bin/yara.sh"
else
    echo "- Wazuh integration: Skipped (agent not installed)"
fi
